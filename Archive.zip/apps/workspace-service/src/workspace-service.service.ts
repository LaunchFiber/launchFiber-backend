import { Injectable } from '@nestjs/common';
import { PrismaService } from '@app/prisma';

@Injectable()
export class WorkspaceService {
    constructor(private readonly prisma: PrismaService) { }

    async create(data: {
        userId: string;
        name: string;
        templateId?: string;
    }) {
        return this.prisma.workspace.create({
            data: {
                name: data.name,
                userId: data.userId,
                templateId: data.templateId,
                status: 'PENDING',
            }
        })
    }
}
