import { Controller } from '@nestjs/common';
import { WorkspaceService } from './workspace-service.service';
import { MessagePattern, Payload } from '@nestjs/microservices';

@Controller()
export class WorkspaceServiceController {
    constructor(private readonly workspaceService: WorkspaceService) { }

    @MessagePattern({ cmd: 'workspace.create' })
    create(
        @Payload()
        data: {
            userId: string;
            name: string;
            templateId?: string;
        },
    ) {
        return this.workspaceService.create(data)
    }

}
